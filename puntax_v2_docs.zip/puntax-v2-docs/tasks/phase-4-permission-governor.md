# Phase 4 Task — Permission Governor

## Goal

Add auditable permission policy and safe candidate rule accrual while preserving `cf-approve` compatibility.

## In scope

- Permission rule schema.
- Permission event logging.
- Risk classifier.
- Candidate rule generation.
- `permission_explain` tool.
- Integration with existing PermissionRequest route.

## Out of scope

- Removing `cf-approve`.
- Auto-activating LLM-generated rules.
- UI-heavy permission management.

## Implementation steps

1. Add permission event type and writer.
2. Implement command normalization and risk classifier.
3. Implement active/candidate rule loading.
4. Add safe repeated-approval candidate generation.
5. Add hard deny/escalate list for destructive operations.
6. Route permission request through governor with `cf-approve` fallback.
7. Add `permission_explain` MCP/CLI helper.
8. Add tests.

## Acceptance criteria

- Existing permission flow still works.
- Destructive commands never auto-promote.
- Safe repeated commands create candidates only.
- Candidate rules are inactive until promotion.
- Permission decisions are logged.

