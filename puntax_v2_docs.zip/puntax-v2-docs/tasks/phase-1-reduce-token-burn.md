# Phase 1 Task — Reduce Token Burn Using Current Architecture

## Goal

Reduce default prompt and precompact token cost while preserving existing behavior and safety.

## In scope

- Add `puntax_context` v0 MCP tool.
- Add prompt/pre-edit/resume token budgets to config.
- Change prompt injection policy to avoid broad session memory by default.
- Add deterministic precompact reducer stub.
- Add feature flags for rollback.

## Out of scope

- Full event ledger.
- Full code-map index.
- Permission governor implementation.
- Tree-sitter/LSP integration.

## Implementation steps

1. Add config keys for PUNTAX context budgets and precompact mode.
2. Implement `puntax_context` v0 in the context-layer MCP server.
3. Make v0 read existing brain files: lessons, file-insights, conventions, hot-files, user-prefs.
4. Add relevance ranking: prompt terms, files, severity, recency, hot-file score.
5. Modify `UserPromptSubmit` behavior so broad session memory is injected only on resume/compaction/relevant prompt.
6. Add `precompact-reducer.mjs` stub that writes a deterministic checkpoint without LLM.
7. Keep `precompact-llm.mjs` available behind config.
8. Add tests.

## Acceptance criteria

- `puntax_context` returns compact context under budget.
- Existing `brain_search`, `semantic_lookup`, and `impact_check` still work.
- Prompt hook can inject no context when nothing is relevant.
- Precompact can run without API key and still write a checkpoint.
- Existing permission flow is unchanged.

## Suggested tests

- Context router returns high-severity matching lesson.
- Context router omits irrelevant memory.
- Context router respects budget.
- Hook imports succeed.
- Precompact reducer writes checkpoint with fake events or empty state.

