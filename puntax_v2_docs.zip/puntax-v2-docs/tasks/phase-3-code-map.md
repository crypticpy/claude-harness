# Phase 3 Task — Code Map Index

## Goal

Turn the context-layer into a real local code intelligence index.

## In scope

- SQLite code-map schema.
- File/symbol table population.
- Edge extraction for contains/imports/exports.
- Staleness detection.
- `semantic_lookup` from index when fresh.
- `impact_check` from edges when available.
- Incremental refresh on post-edit.

## Out of scope

- Advanced call graph resolution for all languages.
- Graph database integration.
- Large architecture visualizations.

## Implementation steps

1. Add code-map schema and storage module.
2. Update active-indexer to parse and store files/symbols.
3. Add parser backend interface.
4. Keep regex parser fallback.
5. Add Tree-sitter backend if dependency policy permits; otherwise design adapter and keep implementation staged.
6. Update semantic_lookup to read from code-map if fresh.
7. Update impact_check to query indexed import edges first.
8. Post-edit hook refreshes changed file.
9. Add tests for stale/fresh behavior.

## Acceptance criteria

- `refresh_index` or active indexer writes real rows.
- `semantic_lookup` avoids re-reading fresh files.
- `impact_check` uses indexed edges when present.
- Stale files are detected by hash.
- Fallback scan still works.

