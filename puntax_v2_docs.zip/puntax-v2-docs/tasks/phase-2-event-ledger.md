# Phase 2 Task — Event Ledger and Deterministic Session Reducer

## Goal

Make structured events the canonical substrate for session continuity.

## In scope

- Event schema and writer/reader.
- Bridge rolling-log/PostToolUse events to event ledger.
- Deterministic checkpoint reducer.
- `session_checkpoint` MCP tool or internal function.
- `what_changed` backed by event ledger.

## Out of scope

- Permission governor policy engine.
- Full code-map indexing.
- LLM distillation changes beyond using checkpoint input.

## Implementation steps

1. Add event types and validation.
2. Implement append-only event writer with corrupted-line tolerant reader.
3. Mirror tool calls, edits, errors, permissions, and tests into event ledger.
4. Implement reducer from events to checkpoint.
5. Write checkpoints to project-local `.claude/context-layer/checkpoints.jsonl`.
6. Update `what_changed` to prefer event ledger.
7. Add tests for event replay.

## Acceptance criteria

- Event ledger writes valid JSONL.
- Reducer reconstructs working files and changed files.
- Corrupted event lines are skipped.
- No LLM required.
- Existing rolling log remains available.

