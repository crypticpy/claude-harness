# Phase 5 Task — Optional LLM Distillation

## Goal

Keep high-value LLM learning while removing routine summarization dependence.

## In scope

- Rename/demote precompact LLM path conceptually to distillation.
- Threshold trigger logic.
- Typed memory proposal output.
- `/evolve` and `/retrospective` use checkpoints/events first.
- Distilled memories have `llm_distilled` confidence.

## Out of scope

- Fully autonomous memory cleanup.
- LLM-created active permission rules.
- Raw transcript-first retrospective by default.

## Implementation steps

1. Add distillation thresholds to config.
2. Update PreCompact to run reducer first.
3. Call LLM only when thresholds trigger or explicit command invoked.
4. Feed LLM checkpoint + selected evidence, not full transcript by default.
5. Parse output as typed memory proposals.
6. Write proposals as memories with `llm_distilled` confidence or pending status.
7. Update evolve/retrospective to prefer event/checkpoint inputs.
8. Add tests with mocked LLM responses.

## Acceptance criteria

- Routine precompact uses no LLM.
- Threshold-triggered distillation works with mock.
- Distilled memory is labeled lower confidence.
- Invalid LLM output is discarded without poisoning memory.
- Existing no-API-key graceful behavior remains.

